bl_info = {
    "name": "voxelcleanup",
    "author": "Lucas Carver",
    "version": (1, 2),
    "blender": (2, 80, 0),
    "location": "View3D > N",
    "description": "Voxelizes model and cleans voxel meshe and pizza",
    "warning": "",
    "doc_url": "",
    "category": "",
}

import bpy
from bpy.types import Panel, Operator
import webbrowser

class CleanOperator(Operator):
    """Cleans voxel model"""
    bl_idname = "clean.simple_operator"
    bl_label = "Simple Clean Operator"

    def execute(self, context):
        from bpy.utils import resource_path
        from pathlib import Path

        USER = Path(resource_path('USER'))
        src = USER / "scripts/addons" / "voxelcleanup"

        file_path = src / "Voxelize.blend"
        inner_path = "NodeTree"
        object_name = "voxel_cleanup"

        bpy.ops.wm.append(
            filepath=str(file_path / inner_path / object_name),
            directory=str(file_path / inner_path),
            filename=object_name
        )
        object = bpy.context.active_object
        modifier = object.modifiers.new("Cleanup", "NODES")
        replacement = bpy.data.node_groups["voxel_cleanup"]
        modifier.node_group = replacement
        bpy.ops.object.modifier_apply(modifier="Cleanup", report=True)
        bpy.ops.object.modifier_add(type='WELD')
        bpy.ops.object.modifier_apply(modifier="Weld", report=True)
        bpy.ops.object.modifier_add(type='DECIMATE')
        bpy.context.object.modifiers["Decimate"].decimate_type = 'DISSOLVE'
        bpy.context.object.modifiers["Decimate"].delimit = {'UV'}
        bpy.ops.object.modifier_apply(modifier="Decimate", report=True)
        bpy.ops.object.modifier_add(type='TRIANGULATE')
        bpy.ops.object.modifier_apply(modifier="Triangulate", report=True)

        return {'FINISHED'}

class CubeOperator(Operator):
    """Voxelizes model"""
    bl_idname = "cube.simple_operator"
    bl_label = "Simple Cube Operator"

    def execute(self, context):
        from bpy.utils import resource_path
        from pathlib import Path

        USER = Path(resource_path('USER'))
        src = USER / "scripts/addons" / "voxelcleanup"

        file_path = src / "Voxelize.blend"
        inner_path = "NodeTree"
        object_name = "Voxelize"

        bpy.ops.wm.append(
            filepath=str(file_path / inner_path / object_name),
            directory=str(file_path / inner_path),
            filename=object_name
        )
        object = bpy.context.active_object
        modifier = object.modifiers.new("Voxel", "NODES")
        replacement = bpy.data.node_groups["Voxelize"]
        modifier.node_group = replacement
        
        return {'FINISHED'}

class GoogleOperator(Operator):
    """Tooltip"""
    bl_idname = "google.simple_operator"
    bl_label = "Open Google Operator"

    def execute(self, context):
        webbrowser.open('https://www.newyorkpizza.nl/')
        return {'FINISHED'}

class CustomPanel(Panel):
    bl_label = "Clean Panel"
    bl_idname = "OBJECT_PT_Clean"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Clean"

    def draw(self, context):
        layout = self.layout
        obj = context.object
        row = layout.row()
        row.operator(CleanOperator.bl_idname, text="clean", icon='MOD_DECIM')
        row = layout.row()
        row.operator(CubeOperator.bl_idname, text="voxelizer", icon='MOD_REMESH')
        row = layout.row()
        row.operator(GoogleOperator.bl_idname, text="pizza", icon='SNAP_NORMAL')

classes = (
    CleanOperator,
    CubeOperator,
    GoogleOperator,
    CustomPanel,
)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)

if __name__ == "__main__":
    register()
